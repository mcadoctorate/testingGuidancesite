# Cornell Notes Worksheet

## Topic: Organizational Tools for Academic Success
### Name: __________________________ Date: ______________

### Essential Question: How can developing effective organizational systems improve academic success?

---

| Questions/Key Ideas | Notes |
|---------------------|-------|
| What are organizational tools? | |
| | |
| | |
| | |
| Why are they important? | |
| | |
| | |
| | |
| What types of organizational tools exist? | |
| | |
| | |
| | |
| How do I choose the right tool for me? | |
| | |
| | |
| | |
| How do I use these tools effectively? | |
| | |
| | |
| | |
| How do organizational tools connect to goal achievement? | |
| | |
| | |
| | |

## Summary:
(Write a summary of what you learned about organizational tools)

```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

## Personal Application:
How will you apply what you've learned about organizational tools to your own academic life?

```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```
