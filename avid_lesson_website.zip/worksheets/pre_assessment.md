# Pre-Assessment Worksheet

## AVID Study Skills & Personal Development
### Name: __________________________ Date: ______________

### Instructions:
Please answer the following questions honestly. This is not a test, but a way for us to understand your current organizational skills and goal-setting practices.

---

### 1. On a scale of 1-5, how organized would you rate yourself with your schoolwork? (1 = not organized at all, 5 = extremely organized)

**Rating: _______**

Explain your rating (Why did you give yourself this score?):
```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

### 2. What tools or methods do you currently use to keep track of assignments and due dates?
```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

### 3. What is one academic or personal goal you have for this school year?
```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

### 4. What steps do you think are necessary to achieve this goal?
```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

### 5. Who are the people in your life that help support your academic success? How do they help you?
```
_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________

_______________________________________________________________________
```

**Thank you for completing this pre-assessment!**
