# Frayer Model Vocabulary Worksheet

## AVID Study Skills & Personal Development
### Name: __________________________ Date: ______________

### Instructions:
Complete the Frayer Model for each of the following vocabulary terms.

---

## Term 1: ORGANIZATION

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |

---

## Term 2: SMART GOALS

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |

---

## Term 3: BACKWARDS MAPPING

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |

---

## Term 4: TIME MANAGEMENT

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |

---

## Term 5: PRIORITIZATION

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |

---

## Term 6: ACCOUNTABILITY

| Definition | Drawing (Visual Representation) |
|------------|--------------------------------|
| | |

| Five Synonyms | Sentence |
|---------------|----------|
| 1. | |
| 2. | |
| 3. | |
| 4. | |
| 5. | |
