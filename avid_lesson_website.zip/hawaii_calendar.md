# Hawaii School Calendar 2025-2026 (Relevant Dates)

## August 2025
- August 7: 7th grader first day
- August 16: Statehood Day (No School)
- August 28: School Open House

## September 2025
- September 2: Labor Day (No School)
- September 20: Waiver Day (No Students)

## October 2025
- October 11: Veterans Day (No School)
- October 31: Waiver Day (No Students)
- October: 1st Quarter ends

## November 2025
- November 5: Election Day
- November 11: Veterans Day (No School)

## Special Days to Avoid for Lesson Planning
- No School Days: August 16, September 2, October 11, November 11
- No Students Days (Waiver Days): September 20, October 31

## Weekly Lessons (Relevant to AVID/Study Skills)
- Week 2: Know Mrs. Anderson
- Week 3: Intro to E-Portfolio & Peace Circle
- Week 4: Cornell Note Taking/Canva.com
- Week 5: Vocab Frayer
- Week 6: Reading SQ3R
- Week 7: Organization Skills
- Week 8: Time Management
- Week 9: Goal Setting
- Week 38: Vision Board
- Week 11: Big Project: Goal Settings & Vision Board
- Week 12: Costa's Levels of Inquiry
- Week 13: Descriptive Writing
- Week 14: Public Speaking & Presentation
- Week 15: Research Skills
- Week 16: Test-Taking Strategies
